var http = require('http');
var apigee = require('apigee-access');
server = http.createServer( function(req, res) {
   // console.log ('Request ::: '+JSON.stringify(req.Body));
    var proxypath = apigee.getVariable(req,'proxy.pathsuffix');
    res.writeHead(200, {'Content-Type': 'application/json'});
    var body1='{ "question_set_no": 300, "survey_sample_percentage": null, "questions": [ { "question_id": 1, "question_no": 1, "question_type": "CES", "question_text": "How satisfied or dissatisfied were you with your experience using Grameenphone web-chat service?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 1, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 2, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 3, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 4, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 5, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 2, "question_no": 2, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the agent‘s helpful & courteous behavior?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 6, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 7, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 8, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 9, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 10, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 3, "question_no": 3, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the solution provided by the agent?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 11, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 12, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 13, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 14, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 15, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 4, "question_no": 4, "question_type": "CES", "question_text": "How satisfied or dissatisfied are you with the time it took to reach an agent?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 16, "option_rating": 1, "option_text": "Very Satisfied" }, { "option_id": 17, "option_rating": 2, "option_text": "Satisfied" }, { "option_id": 18, "option_rating": 3, "option_text": "Neither satisfied nor dissatisfied" }, { "option_id": 19, "option_rating": 4, "option_text": "Dissatisfied" }, { "option_id": 20, "option_rating": 5, "option_text": "Very Dissatisfied" } ] }, { "question_id": 5, "question_no": 5, "question_type": "MCQ", "question_text": "What is your preferred channel to avail customer service?", "answer_type": "Option", "child_questions": [ ], "options": [ { "option_id": 21, "option_rating": 1, "option_text": "Web Chat" }, { "option_id": 22, "option_rating": 2, "option_text": "Facebook" }, { "option_id": 23, "option_rating": 3, "option_text": "E-mail" }, { "option_id": 24, "option_rating": 4, "option_text": "GPC" }, { "option_id": 25, "option_rating": 5, "option_text": "121" } ] }, { "question_id": 6, "question_no": 6, "question_type": "Adhoc", "question_text": "Is there anything else you would like to add?", "answer_type": "Text", "child_questions": [ ], "options": [ ] } ] }';
    var body4 = '{ "statusCode":201, "content":"Survey response saved successfully", "timestamp":1500381807848 }';
    var body3 = '{ "statusCode":401, "content":"Error Occured in Backend", "timestamp":1500381807848 }';
    
    var body = {
  "question_set_no": 300,
  "survey_sample_percentage": null,
  "questions": [
    {
      "question_id": 1,
      "question_no": 1,
      "question_type": "CES",
      "question_text": "How satisfied or dissatisfied were you with your experience using Grameenphone web-chat service?",
      "answer_type": "Option",
      "child_questions": [],
      "options": [
        {
          "option_id": 1,
          "option_rating": 1,
          "option_text": "Very Satisfied"
        },
        {
          "option_id": 2,
          "option_rating": 2,
          "option_text": "Satisfied"
        },
        {
          "option_id": 3,
          "option_rating": 3,
          "option_text": "Neither satisfied nor dissatisfied"
        },
        {
          "option_id": 4,
          "option_rating": 4,
          "option_text": "Dissatisfied"
        },
        {
          "option_id": 5,
          "option_rating": 5,
          "option_text": "Very Dissatisfied"
        }
      ]
    },
    {
      "question_id": 2,
      "question_no": 2,
      "question_type": "CES",
      "question_text": "How satisfied or dissatisfied are you with the agent‘s helpful & courteous behavior?",
      "answer_type": "Option",
      "child_questions": [],
      "options": [
        {
          "option_id": 6,
          "option_rating": 1,
          "option_text": "Very Satisfied"
        },
        {
          "option_id": 7,
          "option_rating": 2,
          "option_text": "Satisfied"
        },
        {
          "option_id": 8,
          "option_rating": 3,
          "option_text": "Neither satisfied nor dissatisfied"
        },
        {
          "option_id": 9,
          "option_rating": 4,
          "option_text": "Dissatisfied"
        },
        {
          "option_id": 10,
          "option_rating": 5,
          "option_text": "Very Dissatisfied"
        }
      ]
    },
    {
      "question_id": 3,
      "question_no": 3,
      "question_type": "CES",
      "question_text": "How satisfied or dissatisfied are you with the solution provided by the agent?",
      "answer_type": "Option",
      "child_questions": [],
      "options": [
        {
          "option_id": 11,
          "option_rating": 1,
          "option_text": "Very Satisfied"
        },
        {
          "option_id": 12,
          "option_rating": 2,
          "option_text": "Satisfied"
        },
        {
          "option_id": 13,
          "option_rating": 3,
          "option_text": "Neither satisfied nor dissatisfied"
        },
        {
          "option_id": 14,
          "option_rating": 4,
          "option_text": "Dissatisfied"
        },
        {
          "option_id": 15,
          "option_rating": 5,
          "option_text": "Very Dissatisfied"
        }
      ]
    },
    {
      "question_id": 4,
      "question_no": 4,
      "question_type": "CES",
      "question_text": "How satisfied or dissatisfied are you with the time it took to reach an agent?",
      "answer_type": "Option",
      "child_questions": [],
      "options": [
        {
          "option_id": 16,
          "option_rating": 1,
          "option_text": "Very Satisfied"
        },
        {
          "option_id": 17,
          "option_rating": 2,
          "option_text": "Satisfied"
        },
        {
          "option_id": 18,
          "option_rating": 3,
          "option_text": "Neither satisfied nor dissatisfied"
        },
        {
          "option_id": 19,
          "option_rating": 4,
          "option_text": "Dissatisfied"
        },
        {
          "option_id": 20,
          "option_rating": 5,
          "option_text": "Very Dissatisfied"
        }
      ]
    },
    {
      "question_id": 5,
      "question_no": 5,
      "question_type": "MCQ",
      "question_text": "What is your preferred channel to avail customer service?",
      "answer_type": "Option",
      "child_questions": [],
      "options": [
        {
          "option_id": 21,
          "option_rating": 1,
          "option_text": "Web Chat"
        },
        {
          "option_id": 22,
          "option_rating": 2,
          "option_text": "Facebook"
        },
        {
          "option_id": 23,
          "option_rating": 3,
          "option_text": "E-mail"
        },
        {
          "option_id": 24,
          "option_rating": 4,
          "option_text": "GPC"
        },
        {
          "option_id": 25,
          "option_rating": 5,
          "option_text": "121"
        }
      ]
    },
    {
      "question_id": 6,
      "question_no": 6,
      "question_type": "Adhoc",
      "question_text": "Is there anything else you would like to add?",
      "answer_type": "Text",
      "child_questions": [],
      "options": []
    }
  ]
};
    res.end(body);
});

port = 3000;
host = '127.0.0.1';
server.listen(port, host);

 