var res = context.getVariable("response.content");
print("RES"+res);